# Intro to Console/Bash

## From the Terminal/Console, using only the command line

1. Create a new folder with the name of `first-day-stuff`
2. Create a new HTML file with the name `first-day.html`
3. Open the folder containing the new HTML file

## Bonus

* Create two directories/folders with the names `one_folder` and `second_folder` using a single command.

* Create two files with the names `one.html` and `two.html` in the `first_day_stuff` directory using a single command.
